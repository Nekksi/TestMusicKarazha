self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dd2fc725337324fef27d56fe95ade786",
    "url": "./index.html"
  },
  {
    "revision": "119e808a740ed014678a",
    "url": "./static/css/2.d0a510e7.chunk.css"
  },
  {
    "revision": "cc60b06df5c9c614b99e",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "119e808a740ed014678a",
    "url": "./static/js/2.b569d8e3.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "./static/js/2.b569d8e3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cc60b06df5c9c614b99e",
    "url": "./static/js/main.7ba3629c.chunk.js"
  },
  {
    "revision": "7429952e3354eec0a2e5",
    "url": "./static/js/runtime-main.68097882.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);