self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e435a4377320733d5427ad029b418218",
    "url": "./index.html"
  },
  {
    "revision": "d85223270c794f883c17",
    "url": "./static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "23717c99bb2de53092d4",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "d85223270c794f883c17",
    "url": "./static/js/2.222990c5.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "./static/js/2.222990c5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "23717c99bb2de53092d4",
    "url": "./static/js/main.b443bbc8.chunk.js"
  },
  {
    "revision": "7429952e3354eec0a2e5",
    "url": "./static/js/runtime-main.68097882.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);