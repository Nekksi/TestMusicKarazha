self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7953119ee2b221c5afa53713c71e06ea",
    "url": "./index.html"
  },
  {
    "revision": "119e808a740ed014678a",
    "url": "./static/css/2.d0a510e7.chunk.css"
  },
  {
    "revision": "7bac1a16f20db5a915c5",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "119e808a740ed014678a",
    "url": "./static/js/2.b569d8e3.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "./static/js/2.b569d8e3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7bac1a16f20db5a915c5",
    "url": "./static/js/main.6d1831e8.chunk.js"
  },
  {
    "revision": "7429952e3354eec0a2e5",
    "url": "./static/js/runtime-main.68097882.js"
  },
  {
    "revision": "c8fd8b04368a3820d0d0b5c6cc6cb11f",
    "url": "./static/media/persik.c8fd8b04.png"
  }
]);