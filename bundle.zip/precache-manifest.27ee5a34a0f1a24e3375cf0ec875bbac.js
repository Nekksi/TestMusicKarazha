self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bac49a77f89a91003ac1b91116d103da",
    "url": "./index.html"
  },
  {
    "revision": "119e808a740ed014678a",
    "url": "./static/css/2.d0a510e7.chunk.css"
  },
  {
    "revision": "4fa042a8154a2f50300a",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "119e808a740ed014678a",
    "url": "./static/js/2.b569d8e3.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "./static/js/2.b569d8e3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4fa042a8154a2f50300a",
    "url": "./static/js/main.5e2be323.chunk.js"
  },
  {
    "revision": "7429952e3354eec0a2e5",
    "url": "./static/js/runtime-main.68097882.js"
  },
  {
    "revision": "e6297a99a6dba441a08fff1ee90e395b",
    "url": "./static/media/persik.e6297a99.png"
  }
]);